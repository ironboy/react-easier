import React from 'react';
import { withContext, useStates, useNamedContext, If, Else } from 'react-easier';
import Person from './Person.jsx';

// Export the component with a named context
export default withContext(
  'global',
  {
    hiGreeting: 'Hi',
    byeGreeting: 'Bye',
    sayHi: true,
    persons: []
  },
  App
);

function App() {

  // States (from context and local)
  const g = useNamedContext('global');
  const s = useStates({
    count: 0,
    name: '',
    age: ''
  });

  // Add a person
  function addPerson(e) {
    e.preventDefault();
    g.persons = [...g.persons, { name: s.name, age: +s.age }];
    s.name = '';
    s.age = '';
  }

  return (
    <div className="App">

      <div>
        <h3>A button<br />that<br />wants to be<br />clicked</h3>
        <button onClick={e => s.count++}>
          I've been clicked<br />{s.count} times
      </button>
      </div>

      <div>
        <h3>Greetings</h3>
        <label>
          How to say Hi:
        <input {...g.bind('hiGreeting')} type="text" />
        </label>
        <label>
          How to say Bye:
        <input {...g.bind('byeGreeting')} type="text" />
        </label>
        <p>Greeting to use:</p>
        <label>
          <input {...g.bind('sayHi', true)} type="radio"></input>
        "{g.hiGreeting}"
      </label>
        <label>
          <input {...g.bind('sayHi', false)} type="radio"></input>
        "{g.byeGreeting}""
      </label>
      </div>

      <div>
        <form onSubmit={addPerson}>
          <h3>Add a person</h3>
          <input {...s.bind('name')} type="text" placeholder="Name" />
          <input {...s.bind('age')} type="number" min="0" max="120" placeholder="Age" />
          <input type="submit" value="Add"></input>
        </form>
      </div>

      <div className="persons">
        <h3>Persons</h3>
        <If c={g.persons.length}>
          <Person loop={g.persons} />
          <Else>
            No persons created yet...
          </Else>
        </If>
      </div>

    </div>
  );
};