import React from 'react';
import { withLoop, useNamedContext, If, ElseIf, Else, } from 'react-easier';

export default withLoop(Person);

function Person(props) {

  let { name, age } = props;
  let g = useNamedContext('global');

  return (
    <div className="Person">
      <h4>{name}</h4>
      <p>{name} is {age} years old. That's
        <If c={age < 30}> young
          <ElseIf c={age < 50}> rather young</ElseIf>
          <ElseIf c={age < 70}> not so old</ElseIf>
          <Else> old</Else>
        </If>
      .</p>
      <p><i>
        <If c={g.sayHi}>
          {g.hiGreeting}! I'm {name} and I'm {age} years old!
          <Else>{g.byeGreeting}! from {name}...</Else>
        </If>
      </i></p>
    </div>
  );
}